import 'package:flutter/material.dart';
import 'widgets/auth_wrapper.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: AuthWrapper(),
  ));
}
